import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Smartphone, 
  ShoppingCart, 
  BarChart3, 
  Search, 
  Package, 
  TrendingUp, 
  Trash2, 
  Edit3, 
  LogOut, 
  History, 
  ArrowUpRight, 
  ArrowDownRight,
  Database,
  User as UserIcon,
  X,
  Menu,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { 
  collection, 
  query, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp, 
  writeBatch,
  orderBy,
  limit
} from 'firebase/firestore';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, db, signInWithGoogle, logout, handleFirestoreError, OperationType } from './lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// --- Utils ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
interface Product {
  id: string;
  brand: string;
  model: string;
  ram?: string;
  storage?: string;
  color?: string;
  priceBuy: number;
  priceSell: number;
  stockCount: number;
}

interface Sale {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  timestamp: any;
}

// --- Components ---

const Button = ({ className, children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button 
    className={cn(
      "px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-all font-semibold active:scale-95 disabled:opacity-50 disabled:pointer-events-none shadow-sm",
      className
    )} 
    {...props}
  >
    {children}
  </button>
);

const Input = ({ className, ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input 
    className={cn(
      "w-full px-4 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all bg-white text-slate-900",
      className
    )} 
    {...props}
  />
);

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory' | 'sales'>('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!user) return;

    const qProducts = query(collection(db, 'products'), orderBy('brand', 'asc'));
    const unsubProducts = onSnapshot(qProducts, (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'products');
    });

    const qSales = query(collection(db, 'sales'), orderBy('timestamp', 'desc'), limit(100));
    const unsubSales = onSnapshot(qSales, (snapshot) => {
      setSales(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Sale)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'sales');
    });

    return () => {
      unsubProducts();
      unsubSales();
    };
  }, [user]);

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-50 text-indigo-600" dir="rtl">
        <Smartphone className="h-12 w-12 animate-bounce" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex h-screen w-full flex-col items-center justify-center bg-slate-100 px-4 text-center font-sans" dir="rtl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white p-8 rounded-lg shadow-xl border border-slate-200"
        >
          <div className="mb-6 flex justify-center">
            <div className="bg-blue-100 p-4 rounded-md">
              <Smartphone className="h-12 w-12 text-blue-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">إدارة متجر الهاتف</h1>
          <p className="text-slate-500 mb-8 leading-relaxed text-sm">
            نظام احترافي لإدارة المبيعات والمخزون لمتجرك الخاص بالهواتف النقالة.
          </p>
          <button 
            onClick={signInWithGoogle}
            className="flex w-full items-center justify-center gap-3 bg-blue-600 text-white py-3 px-6 rounded-md font-bold hover:bg-blue-700 transition-all shadow-md active:scale-95"
          >
            <Smartphone className="h-5 w-5" />
            تسجيل الدخول باستخدام حساب جوجل
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-100 text-slate-900 font-sans" dir="rtl">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="fixed inset-y-0 right-0 z-50 bg-white border-l border-slate-200 shadow-sm flex flex-col md:relative"
      >
        <div className="p-6 flex items-center justify-between border-b border-slate-100 min-h-[80px]">
          {isSidebarOpen ? (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="flex items-center gap-3 font-bold text-xl text-blue-600"
            >
              <Smartphone className="h-8 w-8" />
              <span>نظام المخزون</span>
            </motion.div>
          ) : (
            <Smartphone className="h-8 w-8 text-blue-600 mx-auto" />
          )}
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 md:hidden"
          >
            {isSidebarOpen ? <X /> : <Menu />}
          </button>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          <NavItem 
            icon={<BarChart3 />} 
            label="لوحة التحكم" 
            isActive={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
            collapsed={!isSidebarOpen}
          />
          <NavItem 
            icon={<Package />} 
            label="المخزون" 
            isActive={activeTab === 'inventory'} 
            onClick={() => setActiveTab('inventory')} 
            collapsed={!isSidebarOpen}
          />
          <NavItem 
            icon={<ShoppingCart />} 
            label="المبيعات" 
            isActive={activeTab === 'sales'} 
            onClick={() => setActiveTab('sales')} 
            collapsed={!isSidebarOpen}
          />
        </nav>

        <div className="p-4 border-t border-slate-100">
          <button 
            onClick={logout}
            className={cn(
              "flex items-center gap-3 w-full p-3 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all",
              !isSidebarOpen && "justify-center"
            )}
          >
            <LogOut className="h-5 w-5" />
            {isSidebarOpen && <span className="font-medium">تسجيل الخروج</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-slate-800 text-white border-b border-slate-700 flex items-center justify-between px-8 shrink-0 shadow-md">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
              className="p-2 hover:bg-slate-700 rounded-lg transition-all text-slate-300 hidden md:block"
            >
              {isSidebarOpen ? <ChevronRight /> : <ChevronLeft />}
            </button>
            <div>
              <h2 className="text-xl font-bold">
                {activeTab === 'dashboard' && 'لوحة التحكم والمحاسبة الذكية'}
                {activeTab === 'inventory' && 'إدارة مخزون الهواتف'}
                {activeTab === 'sales' && 'سجل المبيعات والعمليات'}
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-left hidden sm:block">
              <p className="text-xs opacity-70">المسؤول</p>
              <p className="text-sm font-bold leading-none">{user.displayName}</p>
            </div>
            {user.photoURL ? (
              <img src={user.photoURL} className="h-10 w-10 rounded-full border-2 border-slate-600" referrerPolicy="no-referrer" />
            ) : (
              <div className="h-10 w-10 bg-slate-600 rounded-full flex items-center justify-center text-white font-bold">
                {user.displayName?.charAt(0)}
              </div>
            )}
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50/50">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && <DashboardView key="dashboard" products={products} sales={sales} />}
            {activeTab === 'inventory' && <InventoryView key="inventory" products={products} />}
            {activeTab === 'sales' && <SalesView key="sales" products={products} sales={sales} />}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

// --- Subviews ---

function NavItem({ icon, label, isActive, onClick, collapsed }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 w-full p-3 rounded-lg transition-all duration-200",
        isActive 
          ? "bg-blue-600 text-white shadow-md" 
          : "text-slate-600 hover:bg-slate-50 hover:text-blue-600",
          collapsed && "justify-center p-3 px-0"
      )}
    >
      <div className={cn("shrink-0", isActive ? "text-white" : "text-slate-400")}>{icon}</div>
      {!collapsed && <span className="font-semibold tracking-tight">{label}</span>}
    </button>
  );
}

function StatCard({ title, value, icon, trend, trendValue, color }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex flex-col gap-2"
    >
      <div className="flex justify-between items-center">
        <span className="text-slate-500 text-sm font-semibold">{title}</span>
        <div className={cn("p-2 rounded-md", color)}>{icon}</div>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold text-slate-900">{value}</span>
        {trend && (
          <span className={cn(
            "text-xs font-bold px-1.5 py-0.5 rounded",
            trend === 'up' ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
          )}>
            {trend === 'up' ? '+' : '-'}{trendValue}
          </span>
        )}
      </div>
    </motion.div>
  );
}

function DashboardView({ products, sales }: { products: Product[], sales: Sale[], key?: string }) {
  const totalStock = products.reduce((acc, p) => acc + p.stockCount, 0);
  const totalSalesValue = sales.reduce((acc, s) => acc + s.totalPrice, 0);
  const totalInvestment = products.reduce((acc, p) => acc + (p.priceBuy * p.stockCount), 0);
  
  // Calculate total profit from sales
  const totalProfit = sales.reduce((acc, s) => {
    const product = products.find(p => p.id === s.productId);
    if (!product) return acc;
    const itemProfit = (s.unitPrice - product.priceBuy) * s.quantity;
    return acc + itemProfit;
  }, 0);

  // Group sales by date for the chart
  const salesByDate = sales.reduce((acc: any, sale) => {
    const date = format(sale.timestamp?.toDate() || new Date(), 'yyyy-MM-dd');
    if (!acc[date]) acc[date] = 0;
    acc[date] += sale.totalPrice;
    return acc;
  }, {});

  const chartData = Object.entries(salesByDate)
    .sort()
    .slice(-7)
    .map(([date, total]) => ({
      date: format(new Date(date), 'dd/MM', { locale: ar }),
      total
    }));

  return (
    <div className="space-y-6 pb-10">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="إجمالي المخزون" 
          value={`${totalStock} جهاز`} 
          icon={<Package className="h-5 w-5" />} 
          color="bg-slate-100 text-slate-600"
        />
        <StatCard 
          title="قيمة المبيعات" 
          value={`${totalSalesValue.toLocaleString()} د.ج`} 
          icon={<TrendingUp className="h-5 w-5" />} 
          trend="up" 
          trendValue="12%" 
          color="bg-emerald-100 text-emerald-600"
        />
        <StatCard 
          title="الأرباح الصافية" 
          value={`${totalProfit.toLocaleString()} د.ج`} 
          icon={<ShoppingCart className="h-5 w-5" />} 
          color="bg-blue-100 text-blue-600"
        />
        <StatCard 
          title="إجمالي الاستثمار" 
          value={`${totalInvestment.toLocaleString()} د.ج`} 
          icon={<Database className="h-5 w-5" />} 
          color="bg-amber-100 text-amber-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="text-md font-bold text-slate-800 mb-6 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            تحليل المبيعات الأسبوعية
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 11}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 11}} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="total" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#colorTotal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="text-md font-bold text-slate-800 mb-6 flex items-center gap-2">
            <History className="h-5 w-5 text-blue-600" />
            آخر المعاملات
          </h3>
          <div className="space-y-4">
            {sales.slice(0, 6).map((sale) => (
              <div key={sale.id} className="flex items-center gap-3 pb-3 border-b border-slate-50 last:border-0">
                <div className="h-9 w-9 rounded-md bg-slate-50 flex items-center justify-center shrink-0">
                  <Smartphone className="h-4 w-4 text-slate-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-900 truncate">{sale.productName}</p>
                  <p className="text-[10px] text-slate-500">{format(sale.timestamp?.toDate() || new Date(), 'p', { locale: ar })}</p>
                </div>
                <p className="text-xs font-bold text-blue-600">{sale.totalPrice.toLocaleString()}</p>
              </div>
            ))}
            {sales.length === 0 && (
              <div className="text-center py-10">
                <p className="text-slate-400 text-xs italic">لا توجد مبيعات مسجلة بعد</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InventoryView({ products }: { products: Product[], key?: string }) {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState<Partial<Product>>({
    brand: '',
    model: '',
    priceBuy: 0,
    priceSell: 0,
    stockCount: 0,
    ram: '',
    storage: '',
    color: ''
  });

  const filteredProducts = products.filter(p => 
    `${p.brand} ${p.model}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.brand || !formData.model) return;

    try {
      await addDoc(collection(db, 'products'), {
        ...formData,
        lastUpdated: new Date().toISOString()
      });
      setIsAddOpen(false);
      setFormData({ brand: '', model: '', priceBuy: 0, priceSell: 0, stockCount: 0 });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'products');
    }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `products/${id}`);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute right-4 top-2.5 h-4 w-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="بحث عن هاتف أو طراز..." 
            className="w-full pr-10 pl-4 py-2 bg-white border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Button 
            onClick={() => setIsAddOpen(true)}
            className="flex-1 md:flex-none flex items-center justify-center gap-2"
          >
            <Plus className="h-4 w-4" />
            إضافة منتج جديد
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead>
              <tr className="bg-slate-50 border-b-2 border-slate-200">
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">اسم الهاتف</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">الماركة</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">سعر الشراء</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">سعر البيع</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">الكمية المتوفرة</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">الحالة</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50 transition-all">
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-900 text-sm">{p.model}</p>
                    <p className="text-[10px] text-slate-500 uppercase tracking-tighter">{p.ram} / {p.storage} / {p.color}</p>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{p.brand}</td>
                  <td className="px-6 py-4 font-mono text-sm">{p.priceBuy.toLocaleString()}</td>
                  <td className="px-6 py-4 font-mono text-sm text-blue-600 font-bold">{p.priceSell.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">{p.stockCount}</td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase",
                      p.stockCount <= 0 ? "bg-rose-100 text-rose-800" : 
                      p.stockCount <= 5 ? "bg-amber-100 text-amber-800" :
                      "bg-emerald-100 text-emerald-800"
                    )}>
                      {p.stockCount <= 0 ? 'نافذ' : p.stockCount <= 5 ? 'منخفض' : 'متوفر'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 text-slate-400 hover:text-blue-600 transition-all">
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button onClick={() => deleteProduct(p.id)} className="p-1.5 text-slate-400 hover:text-red-600 transition-all">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredProducts.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-20 text-center text-slate-400 text-sm italic">
                    لا توجد منتجات مطابقة للبحث
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal إضافة منتج */}
      <AnimatePresence>
        {isAddOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddOpen(false)}
              className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-lg shadow-2xl p-8 overflow-hidden"
            >
              <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-4">
                <h2 className="text-xl font-bold text-slate-800">إضافة هاتف جديد للمخزون</h2>
                <button onClick={() => setIsAddOpen(false)} className="p-2 hover:bg-slate-100 rounded-md transition-all">
                  <X className="h-5 w-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">الماركة *</label>
                    <Input required value={formData.brand} onChange={e => setFormData({...formData, brand: e.target.value})} placeholder="مثلاً: Samsung" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">الموديل *</label>
                    <Input required value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} placeholder="مثلاً: S24 Ultra" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">سعر الشراء (د.ج) *</label>
                    <Input required type="number" value={formData.priceBuy} onChange={e => setFormData({...formData, priceBuy: Number(e.target.value)})} />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">سعر البيع المقترح (د.ج) *</label>
                    <Input required type="number" value={formData.priceSell} onChange={e => setFormData({...formData, priceSell: Number(e.target.value)})} />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">الكمية *</label>
                    <Input required type="number" value={formData.stockCount} onChange={e => setFormData({...formData, stockCount: Number(e.target.value)})} />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">الرام (RAM)</label>
                    <Input value={formData.ram} onChange={e => setFormData({...formData, ram: e.target.value})} placeholder="12GB" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">التخزين</label>
                    <Input value={formData.storage} onChange={e => setFormData({...formData, storage: e.target.value})} placeholder="512GB" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">اللون</label>
                    <Input value={formData.color} onChange={e => setFormData({...formData, color: e.target.value})} placeholder="أسود" />
                  </div>
                </div>
                <div className="pt-6 flex justify-end gap-3 border-t border-slate-100">
                  <button type="button" onClick={() => setIsAddOpen(false)} className="px-6 py-2 text-sm font-semibold text-slate-500 hover:bg-slate-50 rounded-md transition-all">إلغاء</button>
                  <Button type="submit" className="px-8 py-2">حفظ البيانات</Button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SalesView({ products, sales }: { products: Product[], sales: Sale[], key?: string }) {
  const [isRecordOpen, setIsRecordOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);

  const handleRecordSale = async (e: React.FormEvent) => {
    e.preventDefault();
    const product = products.find(p => p.id === selectedProductId);
    if (!product || product.stockCount < quantity) {
      alert('الكمية المطلوبة غير متوفرة في المخزون');
      return;
    }

    setLoading(true);
    try {
      const batch = writeBatch(db);
      
      // record sale
      const saleRef = doc(collection(db, 'sales'));
      batch.set(saleRef, {
        productId: product.id,
        productName: `${product.brand} ${product.model}`,
        quantity,
        unitPrice: product.priceSell,
        totalPrice: product.priceSell * quantity,
        timestamp: serverTimestamp()
      });

      // update stock
      const productRef = doc(db, 'products', product.id);
      batch.update(productRef, {
        stockCount: product.stockCount - quantity
      });

      await batch.commit();
      setIsRecordOpen(false);
      setSelectedProductId('');
      setQuantity(1);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'sales/batch');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-slate-800">سجل المعاملات</h3>
        <Button onClick={() => setIsRecordOpen(true)} className="flex items-center gap-2">
          <ShoppingCart className="h-4 w-4" />
          تسجيل عملية بيع
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead>
              <tr className="bg-slate-50 border-b-2 border-slate-200">
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">التاريخ</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">اسم الجهاز</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">الكمية</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">سعر الوحدة</th>
                <th className="px-6 py-3 font-semibold text-slate-700 text-xs uppercase tracking-wider">الإجمالي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sales.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50 transition-all">
                  <td className="px-6 py-4 text-xs text-slate-500">
                    {s.timestamp ? format(s.timestamp.toDate(), 'PPP p', { locale: ar }) : '...'}
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-900 text-sm">{s.productName}</td>
                  <td className="px-6 py-4 text-sm">{s.quantity}</td>
                  <td className="px-6 py-4 font-mono text-sm">{s.unitPrice.toLocaleString()}</td>
                  <td className="px-6 py-4 font-black text-blue-600 text-sm">{s.totalPrice.toLocaleString()}</td>
                </tr>
              ))}
              {sales.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center text-slate-400 text-sm italic">
                    لا توجد مبيعات مسجلة
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal تسجيل بيع */}
      <AnimatePresence>
        {isRecordOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsRecordOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl p-8"
            >
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black text-slate-900">تسجيل مبيعات جديد</h2>
                <button onClick={() => setIsRecordOpen(false)} className="p-2 hover:bg-slate-100 rounded-xl">
                  <X />
                </button>
              </div>

              <form onSubmit={handleRecordSale} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">اختر المنتج *</label>
                  <select 
                    required 
                    className="w-full px-4 py-2 bg-white border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 transition-all font-semibold text-sm"
                    value={selectedProductId}
                    onChange={e => setSelectedProductId(e.target.value)}
                  >
                    <option value="">اختر من المخزون...</option>
                    {products.filter(p => p.stockCount > 0).map(p => (
                      <option key={p.id} value={p.id}>{p.brand} {p.model} ({p.stockCount} متوفر)</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">الكمية المباعة *</label>
                  <Input 
                    type="number" 
                    required 
                    min="1" 
                    value={quantity} 
                    onChange={e => setQuantity(Number(e.target.value))} 
                  />
                </div>

                {selectedProductId && (
                  <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-blue-600 font-bold">سعر الوحدة:</span>
                      <span className="font-mono">{products.find(p => p.id === selectedProductId)?.priceSell.toLocaleString()} د.ج</span>
                    </div>
                    <div className="flex justify-between items-center text-xl font-black text-blue-900">
                      <span>الإجمالي:</span>
                      <span>{((products.find(p => p.id === selectedProductId)?.priceSell || 0) * quantity).toLocaleString()} د.ج</span>
                    </div>
                  </div>
                )}

                <div className="pt-6 flex gap-4">
                  <Button disabled={loading} type="submit" className="flex-1 py-3 text-lg">
                    {loading ? 'جاري الحفظ...' : 'تأكيد عملية البيع'}
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
